<!DOCTYPE html>
<html lang="en">
    <head>
        <base href="/public">
        <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <meta name="_token" content="<?php echo e(csrf_token()); ?>">
    </head>
    <body class="sb-nav-fixed">
        <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="layoutSidenav">
                <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div id="layoutSidenav_content">
                    <?php if($errors -> any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><?php echo e($error); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>                                  
                    </div>
                    <?php endif; ?>
                    <?php if(session()->has('message_product')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session()->get('message_product')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>    
                    </div>
                    <?php endif; ?>
                <div class="container">
                    <div class="row">
                        <div class="col-12 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">
                                    <div class="card-header">
                                        <h4 class="card-title">Thêm sản phẩm</h4>
                                        <p class="card-description">Thêm các sản phẩm mới</p>
                                    </div>
                                    <form class="forms-sample" action="<?php echo e(url('/update_product_confirm', $product->product_id)); ?>" method="POST" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="mb-3">
                                          <label class="form-label">Mã sản phẩm :</label>
                                          <input type="text" class="form-control" id="product_id" name="product_id"  value="<?php echo e($product->product_id); ?>" placeholder="Nhập mã giày" readonly>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Tên sản phẩm :</label>
                                            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($product->name); ?>" placeholder="Nhập tên giày">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Mô tả sản phẩm :</label>
                                            <input type="text" class="form-control" id="description" name="description" value="<?php echo e($product->description); ?>" placeholder="Nhập mô tả giày">
                                        </div>                                        
                                        <div class="mb-3">
                                            <label class="form-label">Hình ảnh sản phẩm hiện tại :</label>
                                            <img style="width:50%; height:auto" src="/product/<?php echo e($product->image); ?>">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Thay đổi hình ảnh sản phẩm :</label>
                                            <input class="form-control" type="file" name="image" value="<?php echo e($product->image); ?>" placeholder="Nhập hình ảnh giày">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Danh mục sản phẩm :</label>
                                            <select  class="form-control" id="category" name="category">
                                                <option class="text-color" value="" selected=""><?php echo e($product->category); ?></option>
                                                <?php $__currentLoopData = $catagory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catagory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option class="text-color" value="<?php echo e($catagory->catagory_name); ?>"><?php echo e($catagory->catagory_name); ?></option>        
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Thương hiệu sản phẩm :</label>
                                            <select  class="form-control" id="brand" name="brand">
                                                <option class="text-color" value="" selected=""><?php echo e($product->brand); ?></option>
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Số lượng sản phẩm :</label>
                                            <input type="number" class="form-control" id="quantity" name="quantity" value="<?php echo e($product->quantity); ?>" placeholder="Nhập số lượng giày">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Giá sản phẩm :</label>
                                            <input type="number" class="form-control" id="price" name="price" value="<?php echo e($product->price); ?>" placeholder="Nhập giá giày">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Giảm giá :</label>
                                            <input type="number" class="form-control" id="discount_price"  name="discount_price" value="<?php echo e($product->discount_price); ?>" placeholder="Nhập giảm giày">
                                        </div>  
                                        <button type="submit" class="btn btn-primary" value="Update Product">Lưu</button>
                                      </form>
                                </div>
                            </div>
                        </div>          
                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script type="text/javascript">
            $.ajaxSetup({
                headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                }
            });

            $(document).ready(function(){
                $("#category").change(function(){
                    var catagory_name = $(this).val();

                    if(catagory_name == ""){
                        var catagory_name = 0;
                    }
                    // console.log(catagory_name);
                    $.ajax({
                        url: '<?php echo e(url("/fetch-brand/" )); ?>/' + catagory_name,
                        type: 'post',
                        dataType: 'json',
                        success: function(response){
                            // console.log(response);
                            $("#brand").find('option').remove();
                            $("#brand").append("<option class='text-color' value='"+''+"'>"+'Thêm tại đây'+"</option>");
                            // $("#brand").append("<option class='text-color' value="" selected="">Thêm thương hiệu sản phẩm tại đây</option>")
                            if(response['brands'].length > 0){
                                $.each(response['brands'], function(key, value){
                                    $("#brand").append("<option class='text-color' value='"+value['brands_name']+"'>"+value['brands_name']+"</option>");
                                });
                            }
                        }
                    });
                });
            });
        </script>
    </body>
</html>
<?php /**PATH D:\EcommerceShoe\resources\views/admin/update_product.blade.php ENDPATH**/ ?>