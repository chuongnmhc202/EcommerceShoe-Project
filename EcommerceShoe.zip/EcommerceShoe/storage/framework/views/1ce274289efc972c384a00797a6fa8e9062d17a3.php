<section class="product_section layout_padding">
    <div class="container">
       <div class="heading_container heading_center">
          <h2>
             Sản <span>phẩm</span>
          </h2>
       </div>
       <div class="row">
         <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             
          <div class="col-sm-6 col-md-4 col-lg-4">
             <div class="box">
                <div class="option_container">
                   <div class="options">
                      <a href="<?php echo e(url('product_details', $products->product_id)); ?>" class="option1">
                        Chi tiết
                      </a>
                      <form action="<?php echo e(url('add_cart',  $products->product_id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                           <div class="col-md-4">
                              <input type="number" name="quantity" value="1" min="1" style="width: 100px; padding:12px">
                           </div>
                           <div class="col-md-4">
                              <input type="submit" value="Thêm vào giỏ hàng">
                           </div>
                        </div>
                        
                      </form>
                   </div>
                </div>
                <div class="img-box" >
                   <img src="product/<?php echo e($products->image); ?>" alt="">
                </div>
                <div class="detail-box"  style="display: flex; justify-content: center;" >
                   <h5>
                      <?php echo e($products->name); ?>

                   </h5>                  
                </div>
                <div class="detail-box">
                  <?php if($products->discount_price != $products->price): ?>
                   <h6 style="color: red"> 
                     <?php echo e(number_format($products->discount_price, 0, '', ',')); ?> VNĐ
                   </h6>

                   <h6 style="text-decoration: line-through; color:blue">
                     <?php echo e(number_format($products->price, 0, '', ',')); ?> VNĐ
                   </h6>
                   <?php else: ?>
                   <h6 style="color:blue;">
                     <?php echo e(number_format($products->price, 0, '', ',')); ?> VNĐ
                   </h6>
                   <?php endif; ?>
                </div>
             </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <span style="padding-top: 20px">
            <?php echo $product->withQueryString()->links('pagination::bootstrap-5'); ?>

          </span>
         
    </div>
 </section><?php /**PATH D:\EcommerceShoe\resources\views/home/product.blade.php ENDPATH**/ ?>