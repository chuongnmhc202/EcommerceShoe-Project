<?php echo e($slot); ?>

<?php /**PATH D:\EcommerceShoe\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>