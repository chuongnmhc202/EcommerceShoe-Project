<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body class="sb-nav-fixed">
        <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="layoutSidenav">
                <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div id="layoutSidenav_content">
                    <?php if(session()->has('message_error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo e(session()->get('message_error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>    
                    </div>
                    <?php endif; ?>

                    <?php if(session()->has('message_product')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session()->get('message_product')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>    
                    </div>
                    <?php endif; ?>
                <div class="card-body">
                    <table id="datatablesSimple">
                        <thead>
                            <tr>
                                <th>Tên</th>
                                <th>Mã thanh toán</th>
                                <th>Email</th>
                                <th>Địa chỉ</th>
                                <th>Số điện thoại</th>
                                <th>Tên sản phẩm</th>
                                <th>Số lượng</th>
                                <th>Giá</th>
                                <th>Payment Status</th>
                                <th>Delivery Status</th>
                                <th>Hình ảnh</th>
                                <th>Trạng thái</th>
                                <th>Hành động</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Tên</th>
                                <th>Mã thanh toán</th>
                                <th>Email</th>
                                <th>Địa chỉ</th>
                                <th>Số điện thoại</th>
                                <th>Tên sản phẩm</th>
                                <th>Số lượng</th>
                                <th>Giá</th>
                                <th>Payment Status</th>
                                <th>Delivery Status</th>
                                <th>Hình ảnh</th>
                                <th>Trạng thái</th>
                                <th>Hành động</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($order->name); ?></td>
                                    <td><?php echo e($order->order_number); ?></td>
                                    <td><?php echo e($order->email); ?></td>
                                    <td><?php echo e($order->address); ?></td>
                                    <td><?php echo e($order->phone); ?></td>
                                    <td><?php echo e($order->product_title); ?></td>
                                    <td><?php echo e($order->quantity); ?></td>
                                    <td><?php echo e($order->price); ?></td>
                                    <td><?php echo e($order->payment_status); ?></td>
                                    <td><?php echo e($order->delivery_status); ?></td>
                                    <td>
                                        <img style="width:100px; height:100px" src="/product/<?php echo e($order->image); ?>">
                                    </td>
                                    <td>
                                        
                                        <?php if($order->delivery_status=='Đợi xử lý'): ?>
                                            <a onclick="return confirm('Bạn có chắc là cập nhật không?')" class="btn btn-primary" href="<?php echo e(url('delivered', $order->id)); ?>">Xác nhận</a>
                                        <?php else: ?>
                                            <?php if($order->delivery_status=='Chuyển tới kho'): ?>
                                                <a onclick="return confirm('Bạn có chắc là cập nhật không?')" class="btn btn-danger" href="<?php echo e(url('delivered_acp', $order->id)); ?>">Kết thúc</a>
                                            <?php else: ?>
                                                <a class="btn btn-success">Đã xong</a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        
                                        
                                    </td>
                                    <td>
                                        <a onclick="return confirm('Bạn có chắc muốn in ra không?')" class="btn btn-warning" href="<?php echo e(url('print_pdf', $order->id)); ?>">Hóa đơn</a>
                                        <a class="btn btn-success" href="<?php echo e(url('send_email', $order->id)); ?>">Gửi Mail</a>
        
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </div>      
                </div>
            </div>
        </div>
        <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH D:\EcommerceShoe\resources\views/admin/order.blade.php ENDPATH**/ ?>