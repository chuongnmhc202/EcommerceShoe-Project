<!DOCTYPE html>
<html lang="en">
    <head>
        <base href="/public">
        <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <meta name="_token" content="<?php echo e(csrf_token()); ?>">
    </head>
    <body class="sb-nav-fixed">
        <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="layoutSidenav">
                <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div id="layoutSidenav_content">
                    <?php if($errors -> any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><?php echo e($error); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>                                  
                    </div>
                    <?php endif; ?>
                    <?php if(session()->has('message_product')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session()->get('message_product')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>    
                    </div>
                    <?php endif; ?>
                <div class="container">
                    <div class="row">
                        <div class="col-12 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">
                                    <div class="card-header">
                                        <h4 class="card-title">Gửi mail tới <?php echo e($order->email); ?></h4>
                                    </div>
                                    <form class="forms-sample" action="<?php echo e(url('send_user_email', $order->id)); ?>" method="POST" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="mb-3">
                                          <label class="form-label">Email Greeting :</label>
                                          <input type="text" class="form-control" id="greeting" name="greeting" >
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Email FirstLing :</label>
                                            <input type="text" class="form-control" id="firstline" name="firstline" >
                                          </div>
                                        <div class="mb-3">
                                            <label class="form-label">Email Body :</label>
                                            <input type="text" class="form-control" id="body_name" name="body_name">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Email Button Name :</label>
                                            <input type="text" class="form-control" id="button" name="button">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Email Url :</label>
                                            <input class="form-control" type="text" name="url">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Email LastLing</label>
                                            <input type="text" class="form-control" id="lastline" name="lastline">
                                        </div>
                                                              
                                        <input type="submit" value="Gửi mail" class="btn btn-primary">
                                      </form>
                                </div>
                            </div>
                        </div>          
                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script type="text/javascript">
            $.ajaxSetup({
                headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                }
            });

            $(document).ready(function(){
                $("#category").change(function(){
                    var catagory_name = $(this).val();

                    if(catagory_name == ""){
                        var catagory_name = 0;
                    }
                    // console.log(catagory_name);
                    $.ajax({
                        url: '<?php echo e(url("/fetch-brand/" )); ?>/' + catagory_name,
                        type: 'post',
                        dataType: 'json',
                        success: function(response){
                            // console.log(response);

                            $("#brand").find('option:not(:first)').remove();

                            if(response['brands'].length > 0){
                                $.each(response['brands'], function(key, value){
                                    $("#brand").append("<option class='text-color' value='"+value['brands_name']+"'>"+value['brands_name']+"</option>");
                                });
                            }
                        }
                    });
                });
            });
        </script>
    </body>
</html>
<?php /**PATH D:\EcommerceShoe\resources\views/admin/mail_infor.blade.php ENDPATH**/ ?>