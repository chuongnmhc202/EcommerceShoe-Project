<section class="subscribe_section">
    <div class="container-fuild">
       <div class="box">
          <div class="row">
             <div class="col-md-6 offset-md-3">
                <div class="subscribe_form ">
                   <div class="heading_container heading_center">
                      <h3>Đăng Ký Để Nhận Ưu Đãi Mới Nhất</h3>
                   </div>
                   <p>Đăng ký để được thông báo về các khuyến mãi nhanh và sớm nhất của sóm</p>
                   <form action="">
                      <input type="email" placeholder="Nhập mail của bạn">
                      <button>
                      Đăng ký
                      </button>
                   </form>
                </div>
             </div>
          </div>
       </div>
    </div>
 </section><?php /**PATH D:\EcommerceShoe\resources\views/home/subscribe.blade.php ENDPATH**/ ?>