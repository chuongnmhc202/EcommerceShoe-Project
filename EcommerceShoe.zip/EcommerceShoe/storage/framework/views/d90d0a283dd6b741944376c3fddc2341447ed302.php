<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body class="sb-nav-fixed">
        <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="layoutSidenav">
                <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div id="layoutSidenav_content">
                    <?php if($errors -> any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><?php echo e($error); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>                                  
                    </div>
                    <?php endif; ?>
                    <?php if(session()->has('message')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session()->get('message')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>    
                    </div>
                    <?php endif; ?>
                <div class="container">
                    <div class="row">
                        <div class="col-12 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">
                                    <div class="card-header">
                                        <h4 class="card-title">Thêm danh mục sản phẩm</h4>
                                        <p class="card-description">Thêm các danh mục giày</p>
                                    </div>
                                    <form class="forms-sample" action="<?php echo e(url('/add_category')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="mb-3">
                                          <label for="idCategory" class="form-label">Mã danh mục</label>
                                          <input type="text" class="form-control" id="catagory_id" name="catagory_id" placeholder="Mã danh mục">
                                        </div>
                                        <div class="mb-3">
                                          <label for="nameCategory" class="form-label">Tên danh mục</label>
                                          <input type="text" class="form-control" id="catagory_name" name="catagory_name" placeholder="Tên danh mục">
                                        </div>
                                        <div class="mb-3">
                                            <label for="desCategory" class="form-label">Mô tả danh mục</label>
                                            <input type="text" class="form-control" id="catagory_des" name="catagory_des" placeholder="Mô tả danh mục">
                                          </div>
                                        <button type="submit" class="btn btn-primary">Lưu</button>
                                      </form>
                                </div>
                            </div>
                        </div>          
                    </div>
                </div>
                <div class="card-body">
                    <table id="datatablesSimple">
                        <thead>
                            <tr>
                                <th>Mã danh mục</th>
                                <th>Tên danh mục</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Mã danh mục</th>
                                <th>Tên danh mục</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($data->catagory_id); ?></td>
                                    <td><?php echo e($data->catagory_name); ?></td>
                                    <td><a onclick="return confirm('Bạn có chắc là xóa không?')" class="btn btn-danger" href="<?php echo e(url('delete_catagory', $data->catagory_id)); ?>" >Xóa</a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </div>      
                </div>
            </div>
        </div>
        <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH D:\EcommerceShoe\resources\views/admin/category.blade.php ENDPATH**/ ?>