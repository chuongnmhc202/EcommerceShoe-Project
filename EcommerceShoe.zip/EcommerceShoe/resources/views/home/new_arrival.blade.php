<section class="arrival_section">
    <div class="container">
       <div class="box">
          <div class="arrival_bg_box">
             <img src="home/images/arrival-bg1.png" alt="">
          </div>
          <div class="row">
             <div class="col-md-6 ml-auto">
                <div class="heading_container remove_line_bt">
                   <h2>
                      Bán chạy #1
                   </h2>
                </div>
                <p style="margin-top: 20px;margin-bottom: 30px;">
                   Các sản phẩm của DoubleN luôn đem lại trải nghiệm tốt đẹp. Luôn lắng nghe và cập nhật theo mong muốn của khách hàng.
                </p>
                <a href="{{url('/product_details/CW2288')}}">
                Shop Now
                </a>
             </div>
          </div>
       </div>
    </div>
 </section>