<section class="slider_section ">
	<div class="slider_bg_box carousel slide" data-ride="carousel">
	   <img src="home/images/slider-bg1.jpg" alt="">
	</div>
	<div id="customCarousel1" class="carousel slide" data-ride="carousel">
	   <div class="carousel-inner">
		  <div class="carousel-item active">
			 <div class="container ">
				<div class="row">
				   <div class="col-md-7 col-lg-6 ">
					  <div class="detail-box">
						 <h1>
							<span>
							GIẢM 20%
							</span>
							<br>
							TRÊN MỌI SẢN PHẨM
						 </h1>
						 <div class="btn-box">
							<a href="" class="btn1">
							Mua ngay
							</a>
						 </div>
					  </div>
				   </div>
				</div>
			 </div>
		  </div>
		  <div class="carousel-item ">
			 <div class="container ">
				<div class="row">
				   <div class="col-md-7 col-lg-6 ">
					  <div class="detail-box">
						 <h1>
							<span>
							ĐÓN TẾT
							</span>
							<br>
							CÙNG DOUBLE<span>N</span>
						 </h1>
						 <div class="btn-box">
							<a href="" class="btn1">
							Mua ngay
							</a>
						 </div>
					  </div>
				   </div>
				</div>
			 </div>
		  </div>
		  <div class="carousel-item">
			 <div class="container ">
				<div class="row">
				   <div class="col-md-7 col-lg-6 ">
					  <div class="detail-box">
						 <h1>
							<span>
							Ưu đãi
							</span>
							<br>
							Giảm giá cực sâu
						 </h1>
						 <p>
							Đến ngay với shop để nhận các ưu đãi chất lượng từ shop.
						 </p>
						 <div class="btn-box">
							<a href="" class="btn1">
							Mua ngay
							</a>
						 </div>
					  </div>
				   </div>
				</div>
			 </div>
		  </div>
	   </div>
	   <div class="container">
		  <ol class="carousel-indicators">
			 <li data-target="#customCarousel1" data-slide-to="0" class="active"></li>
			 <li data-target="#customCarousel1" data-slide-to="1"></li>
			 <li data-target="#customCarousel1" data-slide-to="2"></li>
		  </ol>
	   </div>
	</div>
 </section>