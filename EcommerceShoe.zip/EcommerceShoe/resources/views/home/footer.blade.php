<footer>
    <div class="container">
       <div class="row">
          <div class="col-md-4">
              <div class="full">
                 <div class="logo_footer">
                   <a href="#"><img width="210" src="home/images/logo.png" alt="#" /></a>
                 </div>
                 <div class="information_f">
                   <p><strong>ĐỊA CHỈ:</strong> Tân Phong, Quận 7, Tp. Hồ Chí Minh, Việt Nam</p>
                   <p><strong>ĐIỆN THOẠI:</strong> +91 987 654 3210</p>
                   <p><strong>EMAIL:</strong> nhatnghiatyper@gmail.com</p>
                 </div>
              </div>
          </div>
          <div class="col-md-8">
             <div class="row">
             <div class="col-md-7">
                <div class="row">
                   <div class="col-md-6">
                <div class="widget_menu">
                   <h3>Menu</h3>
                   <ul>
                      <li><a href="#">Trang chủ</a></li>
                      <li><a href="#">Về chúng tôi</a></li>
                      <li><a href="#">Dịch vụ</a></li>
                      <li><a href="#">Đánh giá</a></li>
                      <li><a href="#">Blog</a></li>
                      <li><a href="#">Liên hệ</a></li>
                   </ul>
                </div>
             </div>
             <div class="col-md-6">
                
             </div>
                </div>
             </div>     
             <div class="col-md-5">
                <div class="widget_menu">
                   <h3>Bản tin</h3>
                   <div class="information_f">
                     <p>Đăng ký để nhận được những thông tin mới nhất.</p>
                   </div>
                   <div class="form_sub">
                      <form>
                         <fieldset>
                            <div class="field">
                               <input type="email" placeholder="Nhập mail của bạn" name="email" />
                               <input type="submit" value="Đăng ký" />
                            </div>
                         </fieldset>
                      </form>
                   </div>
                </div>
             </div>
             </div>
          </div>
       </div>
    </div>
 </footer>
 <!-- footer end -->
 <div class="cpy_">
    <p class="mx-auto">© 2022 All Rights Reserved By <a href="https://www.facebook.com/NghiaDauLau/">Nhat nghia</a><br>
    
       Distributed By <a href="https://www.facebook.com/NghiaDauLau/" target="_blank">NhatNghia</a>
    
    </p>
 </div>